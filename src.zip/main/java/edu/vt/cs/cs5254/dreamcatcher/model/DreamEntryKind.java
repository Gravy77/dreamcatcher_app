package edu.vt.cs.cs5254.dreamcatcher.model;

public enum DreamEntryKind {

    REVEALED, DEFERRED, REALIZED, COMMENT;
}
