package edu.vt.cs.cs5254.dreamcatcher;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.List;

import edu.vt.cs.cs5254.dreamcatcher.model.Dream;

public class DreamAdapter extends RecyclerView.Adapter<DreamHolder>{

    // model field
    private List<Dream> mDreams;

    public DreamAdapter(List<Dream> dreams) {

        mDreams = dreams;
    }

    @NonNull
    @Override
    public DreamHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return new DreamHolder(inflater, parent);
    }

    @Override
    public void onBindViewHolder(@NonNull DreamHolder holder, int position) {
        holder.bind(mDreams.get(position));
    }

    @Override
    public int getItemCount() {

        return mDreams.size();
    }

    public void setDreams(List<Dream> dreams) {
        mDreams = dreams;
    }
}
