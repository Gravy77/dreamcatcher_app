package edu.vt.cs.cs5254.dreamcatcher;

import androidx.fragment.app.Fragment;

public class DreamListActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() {
        return new DreamListFragment();
    }
}
