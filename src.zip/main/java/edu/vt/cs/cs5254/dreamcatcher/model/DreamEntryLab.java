package edu.vt.cs.cs5254.dreamcatcher.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import edu.vt.cs.cs5254.dreamcatcher.database.DreamBaseHelper;
import edu.vt.cs.cs5254.dreamcatcher.database.DreamCursorWrapper;
import edu.vt.cs.cs5254.dreamcatcher.database.DreamDbSchema.DreamEntryTable;
import edu.vt.cs.cs5254.dreamcatcher.database.DreamEntryCursorWrapper;


public class DreamEntryLab {

    private static DreamEntryLab sDreamEntryLab;
    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static DreamEntryLab getInstance(Context context) {
        if (sDreamEntryLab == null) {
            sDreamEntryLab = new DreamEntryLab(context);
        }
        return sDreamEntryLab;
    }

    private DreamEntryLab(Context context) {

        mContext = context.getApplicationContext();
        mDatabase = new DreamBaseHelper(mContext)
                .getWritableDatabase();
    }

    public void addDreamEntry(DreamEntry dreamEntry, Dream dream) {
        ContentValues values = getDreamEntryValues(dreamEntry, dream);
        mDatabase.insert(DreamEntryTable.NAME, null, values);
    }

    private ContentValues getDreamEntryValues(DreamEntry dreamEntry, Dream dream) {
        ContentValues values = new ContentValues();
        values.put(DreamEntryTable.Cols.TEXT, dreamEntry.getEntryText());
        values.put(DreamEntryTable.Cols.KIND, dreamEntry.getEntryKind().toString());
        values.put(DreamEntryTable.Cols.DATE, dreamEntry.getEntryDate().getTime());
        values.put(DreamEntryTable.Cols.UUID, dream.getId().toString());
        return values;
    }

    public List<DreamEntry> getDreamEntries(Dream dream) {
        List<DreamEntry> dreamEntries = new ArrayList<>();
        DreamEntryCursorWrapper cursor = queryDreamEntries(
              DreamEntryTable.Cols.UUID + " = ?",
              new String[] { dream.getId().toString() });

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                dreamEntries.add(cursor.getDreamEntry());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }
        return dreamEntries;
    }

    private DreamEntryCursorWrapper queryDreamEntries(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                DreamEntryTable.NAME,
                null,
                 whereClause,
                 whereArgs,
                null,
                null,
                null
        );
        return new DreamEntryCursorWrapper(cursor);
    }

    public void updateDreamEntries(Dream dream) {
        // Remove all the old entries associated with the dream from the database
        String uuidString = dream.getId().toString();

        mDatabase.delete(DreamEntryTable.NAME,
                DreamEntryTable.Cols.UUID + " = ?",
                new String[] { uuidString });

        // Re-Enter updated dream entries
        for (DreamEntry entry : dream.getEntries()) {
            DreamEntryLab.getInstance(mContext).addDreamEntry(entry, dream);
        }
    }
}
