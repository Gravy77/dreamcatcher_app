package edu.vt.cs.cs5254.dreamcatcher;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import edu.vt.cs.cs5254.dreamcatcher.model.Dream;

public class DreamHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    //model field
    private Dream mDream;

    //view fields
    TextView mTitleTextView;
    TextView mDateTextView;
    ImageView mImageView;

    public DreamHolder(LayoutInflater inflater, ViewGroup parent) {
        super(inflater.inflate(R.layout.list_item_dream, parent, false));

        mTitleTextView = itemView.findViewById(R.id.dream_title);
        mDateTextView = itemView.findViewById(R.id.dream_entry_0_button);
        mImageView = itemView.findViewById(R.id.dream_icon);

        itemView.setOnClickListener(this);
    }

    public void bind(Dream dream) {
        mDream = dream;
        mTitleTextView.setText(dream.getTitle());
        mDateTextView.setText(dream.getDate().toString());
        if (dream.isDeferred()) {
            mImageView.setImageResource(R.drawable.dream_deferred_icon);
            mImageView.setTag(R.drawable.dream_deferred_icon);
        } else if (dream.isRealized()){
            mImageView.setImageResource(R.drawable.dream_realized_icon);
            mImageView.setTag(R.drawable.dream_realized_icon);
        } else {
            mImageView.setImageResource(0);
            mImageView.setTag(0);
        }
    }

    @Override
    public void onClick(View v) {
        Context context = itemView.getContext();
        Intent intent = DreamActivity.newIntent(context, mDream.getId());
        context.startActivity(intent);
    }
}
