package edu.vt.cs.cs5254.dreamcatcher;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import edu.vt.cs.cs5254.dreamcatcher.model.Dream;
import edu.vt.cs.cs5254.dreamcatcher.model.DreamEntry;
import edu.vt.cs.cs5254.dreamcatcher.model.DreamEntryKind;
import edu.vt.cs.cs5254.dreamcatcher.model.DreamLab;
import edu.vt.cs.cs5254.dreamcatcher.model.PictureUtils;

import static androidx.core.content.ContextCompat.checkSelfPermission;

public class DreamFragment extends Fragment {

    private static final String TAG = "DreamFragment";

    private final static int REVEALED_COLOR = 0xff0076ba;
    private final static int REALIZED_COLOR = 0xff008f00;
    private final static int DEFERRED_COLOR = 0xffb51700;
    private final static int COMMENT_COLOR = 0xffffd479;

    public static final String ARG_DREAM_ID = "dream_id";
    private static final int REQUEST_COMMENT = 0;
    private static final String DIALOG_ADD_DREAM_ENTRY = "DialogAddDreamEntry";
    private static final int REQUEST_PHOTO = 1;
    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 10;

    //model fields
    private Dream mDream;
    private File mPhotoFile;

    // view fields
    private EditText mTitleField;
    private ImageView mPhotoView;
    private CheckBox mRealizedCheckBox;
    private CheckBox mDeferredCheckBox;
    private FloatingActionButton mAddCommentFAB;

    // recycler view
    private RecyclerView mDreamEntryRecyclerView;
    private DreamEntryAdapter mAdapter;

    public static Fragment newInstance(UUID dreamId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_DREAM_ID, dreamId);
        DreamFragment fragment = new DreamFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        UUID dreamId = (UUID) getArguments().getSerializable(ARG_DREAM_ID);
        mDream = DreamLab.getInstance(getActivity()).getDream(dreamId);
        mPhotoFile = DreamLab.getInstance(getActivity()).getPhotoFile(mDream);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.v(TAG, "Test Log Message 12345");
        View view = inflater.inflate(R.layout.fragment_dream, container, false);
        // initialize view fields

        // find view title
        mTitleField = view.findViewById(R.id.dream_title);
        // refresh view title based on the model
        // listener
        mTitleField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                mDream.setTitle(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                //
            }
        });

        // find view checkbox
        mRealizedCheckBox = view.findViewById(R.id.dream_realized);
        // refresh
        mRealizedCheckBox.setChecked(mDream.isRealized());
        // listener (for the checkbox)
        mRealizedCheckBox.setOnCheckedChangeListener(
                (compoundButton, checked) -> {
                    if (checked) {
                        mDream.selectDreamRealized();
                    } else {
                        mDream.deselectDreamRealized();
                    }
                    refreshView();
                });
        // find view revealed checkbox
        mDeferredCheckBox = view.findViewById(R.id.dream_deferred);
        // listener
        mDeferredCheckBox.setOnCheckedChangeListener(
                (compoundButton, checked) -> {
                    if (checked) {
                        mDream.selectDreamDeferred();
                    } else {
                        mDream.deselectDreamDeferred();
                    }
                    refreshView();
                });

        mDreamEntryRecyclerView = view.findViewById(R.id.dream_entry_recycler_view);
        mDreamEntryRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mAddCommentFAB = view.findViewById(R.id.add_comment_fab);
        mAddCommentFAB.setOnClickListener(v -> {
            FragmentManager manager = DreamFragment.this.getFragmentManager();
            AddDreamEntryFragment dialog = new AddDreamEntryFragment();
            dialog.setTargetFragment(DreamFragment.this, REQUEST_COMMENT);
            dialog.show(manager, DIALOG_ADD_DREAM_ENTRY);
        });

        mPhotoView = view.findViewById(R.id.dream_photo);

        refreshView();
        return view;
    }

    @Override
    public void onPause() {
        super.onPause();
        DreamLab.getInstance(getActivity())
                .updateDream(mDream);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_dream, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG, "Options Item Selected");
        switch (item.getItemId()) {
            case R.id.share_dream:
                Log.d(TAG, "Share Dream Option Item Selected");
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, getDreamReport());
                i.putExtra(Intent.EXTRA_SUBJECT, mDream.getTitle());
                i = Intent.createChooser(i, getString(R.string.send_report));
                startActivity(i);
                return true;
            case R.id.take_dream_photo:
                Log.d(TAG, "Take Photo Option Item Selected");
                checkCameraPermission();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void takePhotoOption() {
        Intent captureImage = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Uri uri = FileProvider.getUriForFile(getActivity(),
                "edu.vt.cs.cs5254.dreamcatcher.fileprovider",
                mPhotoFile);
        captureImage.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        List<ResolveInfo> cameraActivities = getActivity()
                .getPackageManager().queryIntentActivities(captureImage,
                        PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo activity : cameraActivities) {
            getActivity().grantUriPermission(activity.activityInfo.packageName,
                    uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        }
        startActivityForResult(captureImage, REQUEST_PHOTO);
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Log.i(TAG, "Camera permission granted.");
            takePhotoOption();
        }
        Log.i(TAG, "Camera permission NOT granted.");
        requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        Log.d(TAG,
                "Camera Permission Callback triggered. (In DreamFragment).  " +
                        "Result is: " + grantResults[0]);

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! do the task.
                    takePhotoOption();
                } else {
                    // permission was denied. explain to the user why a photo can't be taken.
                    Toast.makeText(getActivity(), "Camera Permission was denied.  Unable to take Photo.", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    private String getDreamReport() {
        StringBuilder sb = new StringBuilder();
        sb.append(mDream.getTitle());
        sb.append(System.getProperty("line.separator"));
        for (DreamEntry e : mDream.getEntries()) {
            sb.append(e.getEntryText());
            // ALSO APPEND THE DATE IN PARENS
            sb.append(System.getProperty("line.separator"));
        }
        return sb.toString();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == REQUEST_COMMENT) {
            String comment =
                    (String) intent.getSerializableExtra(AddDreamEntryFragment.EXTRA_COMMENT);
            mDream.addComment(comment);
            refreshDreamEntries();
        }

        if (requestCode == REQUEST_PHOTO) {
            Uri uri = FileProvider.getUriForFile(getActivity(),
                    "edu.vt.cs.cs5254.dreamcatcher.fileprovider",
                    mPhotoFile);
            getActivity().revokeUriPermission(uri,
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            refreshPhotoView();
        }
    }

    // =========================================================================
    // refreshing view
    // =========================================================================

    private void refreshView() {
        mTitleField.setText(mDream.getTitle());
        refreshPhotoView();
        refreshCheckBoxes();
        refreshDreamEntries();
        if (!mDream.isRealized() && !mDream.isDeferred()) {
            mAddCommentFAB.setEnabled(true);
        } else {
            mAddCommentFAB.setEnabled(false);
        }
        mAddCommentFAB.bringToFront();
    }

    private void refreshPhotoView() {
        if (mPhotoFile == null || !mPhotoFile.exists()) {
            mPhotoView.setImageDrawable(null);
        } else {
            Bitmap bitmap = PictureUtils.getScaledBitmap(
                    mPhotoFile.getPath(), getActivity());
            mPhotoView.setImageBitmap(bitmap);
        }
    }

    private void refreshCheckBoxes() {
        if (mDream.isRealized()) {
            mRealizedCheckBox.setEnabled(true);
            mRealizedCheckBox.setChecked(true);
            mDeferredCheckBox.setEnabled(false);
            mDeferredCheckBox.setChecked(false);
        } else if (mDream.isDeferred()) {
            mRealizedCheckBox.setEnabled(false);
            mRealizedCheckBox.setChecked(false);
            mDeferredCheckBox.setEnabled(true);
            mDeferredCheckBox.setChecked(true);
        } else {
            mRealizedCheckBox.setEnabled(true);
            mRealizedCheckBox.setChecked(false);
            mDeferredCheckBox.setEnabled(true);
            mDeferredCheckBox.setChecked(false);
        }
    }

    private void refreshDreamEntries() {
        mAdapter = new DreamEntryAdapter(mDream.getEntries());
        mDreamEntryRecyclerView.setAdapter(mAdapter);
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeToDeleteCallback(mAdapter));
        itemTouchHelper.attachToRecyclerView(mDreamEntryRecyclerView);
    }

    private void setRevealedStyle(Button button) {
        button.getBackground().setColorFilter(REVEALED_COLOR, PorterDuff.Mode.MULTIPLY);
        button.setTextColor(Color.WHITE);
    }

    private void setDeferredStyle(Button button) {
        button.getBackground().setColorFilter(DEFERRED_COLOR, PorterDuff.Mode.MULTIPLY);
        button.setTextColor(Color.WHITE);
    }

    private void setRealizedStyle(Button button) {
        button.getBackground().setColorFilter(REALIZED_COLOR, PorterDuff.Mode.MULTIPLY);
        button.setTextColor(Color.WHITE);
    }

    private void setCommentStyle(Button button) {
        button.getBackground().setColorFilter(COMMENT_COLOR, PorterDuff.Mode.MULTIPLY);
        button.setTextColor(Color.BLACK);
    }

    // recycler view inner classes begin here

    private class DreamEntryHolder extends RecyclerView.ViewHolder {

        // model field
        private DreamEntry mDreamEntry;
        // view field
        private Button mDreamEntryButton;

        public DreamEntryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_dream_entry, parent, false));
            mDreamEntryButton = itemView.findViewById(R.id.dream_entry_button);
        }

        public void bind(DreamEntry dreamEntry) {
            mDreamEntry = dreamEntry;
            DreamEntryKind dreamEntryKind = mDreamEntry.getEntryKind();
            switch (dreamEntryKind) {
                case REVEALED: setRevealedStyle(mDreamEntryButton);
                    break;
                case DEFERRED: setDeferredStyle(mDreamEntryButton);
                    break;
                case REALIZED: setRealizedStyle(mDreamEntryButton);
                    break;
                case COMMENT: setCommentStyle(mDreamEntryButton);
                    break;
            }

            String pattern = "MMM d, yyyy";
            SimpleDateFormat  simpleDateFormat = new SimpleDateFormat(pattern);
            String date = simpleDateFormat.format(dreamEntry.getEntryDate());
            mDreamEntryButton.setText(dreamEntry.getEntryText() + " (" + date + ")");
        }
    }

    private class DreamEntryAdapter extends RecyclerView.Adapter<DreamEntryHolder> {

        private List<DreamEntry> mDreamEntries;

        public DreamEntryAdapter(List<DreamEntry> dreamEntries) {
            mDreamEntries = dreamEntries;
        }

        @NonNull
        @Override
        public DreamEntryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new DreamEntryHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull DreamEntryHolder holder, int position) {
            DreamEntry dreamEntry = mDreamEntries.get(position);
            holder.bind(dreamEntry);
        }

        @Override
        public int getItemCount() {
            return mDreamEntries.size();
        }

        public void deleteItem(int position) {
            if (mDream.getEntries().get(position).getEntryKind() == DreamEntryKind.COMMENT) {
                mDream.getEntries().remove(position);
                notifyItemRemoved(position);
                refreshDreamEntries();
            }
        }
    }

    public class SwipeToDeleteCallback extends ItemTouchHelper.SimpleCallback {

        private DreamEntryAdapter mAdapter;

        public SwipeToDeleteCallback(DreamEntryAdapter adapter) {
            super(0, ItemTouchHelper.LEFT);
            mAdapter = adapter;
        }

        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            int position = viewHolder.getAdapterPosition();
            mAdapter.deleteItem(position);
        }
    }
}
