package edu.vt.cs.cs5254.dreamcatcher.model;

import java.util.Date;
import java.util.UUID;

public class DreamEntry {

    private String mEntryText;
    private Date mEntryDate;
    private DreamEntryKind mEntryKind;

    public DreamEntry(String entryText, Date entryDate, DreamEntryKind entryKind) {
        mEntryText = entryText;
        mEntryDate = entryDate;
        mEntryKind = entryKind;
    }

    public String getEntryText() {
        return mEntryText;
    }

    public void setEntryText(String entryText) {
        mEntryText = entryText;
    }

    public Date getEntryDate() {
        return mEntryDate;
    }

    public DreamEntryKind getEntryKind() {
        return mEntryKind;
    }

    public void setEntryKind(DreamEntryKind entryKind) {
        mEntryKind = entryKind;
    }

    public void setDate(Date date) {
        mEntryDate = date;
    }
}
