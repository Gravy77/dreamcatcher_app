package edu.vt.cs.cs5254.dreamcatcher;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("This is the main activity");
        Log.i(TAG, "Running as expected.");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
