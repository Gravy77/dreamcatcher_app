package edu.vt.cs.cs5254.dreamcatcher.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.Date;
import java.util.UUID;

import edu.vt.cs.cs5254.dreamcatcher.database.DreamDbSchema.DreamEntryTable;
import edu.vt.cs.cs5254.dreamcatcher.model.Dream;
import edu.vt.cs.cs5254.dreamcatcher.model.DreamEntry;
import edu.vt.cs.cs5254.dreamcatcher.model.DreamEntryKind;


public class DreamEntryCursorWrapper extends CursorWrapper {

    public DreamEntryCursorWrapper(Cursor cursor) {
        super(cursor); }

    public DreamEntry getDreamEntry() {
        String text = getString(getColumnIndex(DreamEntryTable.Cols.TEXT));
        long date = getLong(getColumnIndex(DreamEntryTable.Cols.DATE));
        String kind = getString(getColumnIndex(DreamEntryTable.Cols.KIND));
        DreamEntry dreamEntry = new DreamEntry(text, new Date(date), DreamEntryKind.valueOf(kind));
        return dreamEntry;
    }
}
