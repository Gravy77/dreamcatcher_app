package edu.vt.cs.cs5254.dreamcatcher;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import java.util.List;
import java.util.UUID;

import static edu.vt.cs.cs5254.dreamcatcher.DreamFragment.MY_PERMISSIONS_REQUEST_CAMERA;

public class DreamActivity extends SingleFragmentActivity {

    private static final String EXTRA_DREAM_ID = "dreamcatcher.dream_id";
    private static final String TAG = DreamActivity.class.getSimpleName();

    public static Intent newIntent(Context packageContext, UUID dreamId) {
        System.out.println("This is the DreamActivity");
        Intent intent = new Intent(packageContext, DreamActivity.class);
        intent.putExtra(EXTRA_DREAM_ID, dreamId);
        return intent;
    }
    @Override
    protected Fragment createFragment() {
        UUID dreamId = (UUID) getIntent().getSerializableExtra(EXTRA_DREAM_ID);
        return DreamFragment.newInstance(dreamId);
    }
}
